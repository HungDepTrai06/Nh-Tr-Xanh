﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebBanHang.Models;
using PagedList;
namespace WebBanHang.Areas.QuanTri_ND.Controllers
{
    public class TINTUCsController : Controller
    {
        private DBWebThue db = new DBWebThue();

        // GET: QuanTri_ND/TINTUCs
        public ActionResult Index(int? page, string keySearch)
        {
            List<TINTUC> dstt = null;
            if (keySearch != null)
            {
                dstt = db.TINTUC.Where(x => x.NoiDung.ToUpper().Contains(keySearch) || x.TienIch.ToUpper().Contains(keySearch) || x.DichVu.ToUpper().Contains(keySearch) || x.TieuDe.ToUpper().Contains(keySearch) || x.GiaTien.ToString().Contains(keySearch)).ToList();
                ViewBag.tieude = "kết quả tìm được";
            }
            dstt = db.TINTUC.OrderBy(x => x.MaLoaiTT).ToList();
            int pagesize = 6;
            int pagenumber = page ?? 1;
            return View(dstt.ToPagedList(pagenumber, pagesize));
        }

        // GET: QuanTri_ND/TINTUCs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TINTUC tINTUC = db.TINTUC.Find(id);
            if (tINTUC == null)
            {
                return HttpNotFound();
            }
            return View(tINTUC);
        }

        // GET: QuanTri_ND/TINTUCs/Create
        public ActionResult Create()
        {
            ViewBag.MaHuyen = new SelectList(db.HUYENQUAN, "MaHuyen", "MaTinh");
            ViewBag.MaND = new SelectList(db.NGUOIDUNG, "MaND", "TenDangNhap");
            ViewBag.MaPhuong = new SelectList(db.PHUONGXA, "MaPhuong", "MaHuyen");
            ViewBag.MaLoaiTT = new SelectList(db.THELOAITIN, "MaLoaiTT", "TenTL");
            return View();
        }

        // POST: QuanTri_ND/TINTUCs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID_TinTuc,TieuDe,Anh,NoiDung,MaHuyen,MaTinh,MaPhuong,MaND,DienTich,DiaChi,GiaTien,SoNguoiToiDa,TienIch,GiaDien,DichVu,MaLoaiTT,TrangThai")] TINTUC tINTUC)
        {
            if (ModelState.IsValid)
            {
                db.TINTUC.Add(tINTUC);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.MaHuyen = new SelectList(db.HUYENQUAN, "MaHuyen", "MaTinh", tINTUC.MaHuyen);
            ViewBag.MaND = new SelectList(db.NGUOIDUNG, "MaND", "TenDangNhap", tINTUC.MaND);
            ViewBag.MaPhuong = new SelectList(db.PHUONGXA, "MaPhuong", "MaHuyen", tINTUC.MaPhuong);
            ViewBag.MaLoaiTT = new SelectList(db.THELOAITIN, "MaLoaiTT", "TenTL", tINTUC.MaLoaiTT);
            return View(tINTUC);
        }

        // GET: QuanTri_ND/TINTUCs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TINTUC tINTUC = db.TINTUC.Find(id);
            if (tINTUC == null)
            {
                return HttpNotFound();
            }
     
            ViewBag.MaLoaiTT = new SelectList(db.THELOAITIN, "MaLoaiTT", "TenTL", tINTUC.MaLoaiTT);
            return View(tINTUC);
        }

        // POST: QuanTri_ND/TINTUCs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID_TinTuc,TieuDe,Anh,NoiDung,MaHuyen,MaTinh,MaPhuong,MaND,DienTich,DiaChi,GiaTien,SoNguoiToiDa,TienIch,GiaDien,DichVu,MaLoaiTT,TrangThai")] TINTUC tINTUC)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tINTUC).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
          
            ViewBag.MaLoaiTT = new SelectList(db.THELOAITIN, "MaLoaiTT", "TenTL", tINTUC.MaLoaiTT);
            return View(tINTUC);
        }

        // GET: QuanTri_ND/TINTUCs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TINTUC tINTUC = db.TINTUC.Find(id);
            if (tINTUC == null)
            {
                return HttpNotFound();
            }
            return View(tINTUC);
        }

        // POST: QuanTri_ND/TINTUCs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            TINTUC tINTUC = db.TINTUC.Find(id);
            db.TINTUC.Remove(tINTUC);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
