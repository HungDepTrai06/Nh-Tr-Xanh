﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WebBanHang.Models;

namespace WebBanHang.Areas.QuanTri_ND.Controllers
{
    public class THELOAITINsController : Controller
    {
        private DBWebThue db = new DBWebThue();

        // GET: QuanTri_ND/THELOAITINs
        public ActionResult Index()
        {
            return View(db.THELOAITIN.ToList());
        }

        // GET: QuanTri_ND/THELOAITINs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            THELOAITIN tHELOAITIN = db.THELOAITIN.Find(id);
            if (tHELOAITIN == null)
            {
                return HttpNotFound();
            }
            return View(tHELOAITIN);
        }

        // GET: QuanTri_ND/THELOAITINs/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: QuanTri_ND/THELOAITINs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "MaLoaiTT,TenTL")] THELOAITIN tHELOAITIN)
        {
            if (ModelState.IsValid)
            {
                db.THELOAITIN.Add(tHELOAITIN);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(tHELOAITIN);
        }

        // GET: QuanTri_ND/THELOAITINs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            
            THELOAITIN tHELOAITIN = db.THELOAITIN.Find(id);
            if (tHELOAITIN == null)
            {
                return HttpNotFound();
            }
            return View(tHELOAITIN);
        }

        // POST: QuanTri_ND/THELOAITINs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "MaLoaiTT,TenTL")] THELOAITIN tHELOAITIN)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tHELOAITIN).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(tHELOAITIN);
        }

        // GET: QuanTri_ND/THELOAITINs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            if(db.TINTUC.SingleOrDefault(x=>x.MaLoaiTT==id)!=null)
            {
                ModelState.AddModelError("","Không thể xóa thể loại tin này");
                return View("Index");
            }
            THELOAITIN tHELOAITIN = db.THELOAITIN.Find(id);
            if (tHELOAITIN == null)
            {
                return HttpNotFound();
            }
            return View(tHELOAITIN);
        }

        // POST: QuanTri_ND/THELOAITINs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            THELOAITIN tHELOAITIN = db.THELOAITIN.Find(id);
            db.THELOAITIN.Remove(tHELOAITIN);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
