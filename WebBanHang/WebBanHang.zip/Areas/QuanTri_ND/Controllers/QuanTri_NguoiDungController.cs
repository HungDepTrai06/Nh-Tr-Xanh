﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanHang.Models;
using PagedList;
using System.Net;
using System.Data.Entity;

namespace WebBanHang.Areas.QuanTri_ND.Controllers
{
    public class QuanTri_NguoiDungController : Controller
    {
        DBWebThue db = new DBWebThue();
        // GET: QuanTri_ND/QuanTri_NguoiDung
        public ActionResult Index(int? page)
        {
            NGUOIDUNG kh = (NGUOIDUNG)Session["KhachHang"];
            ViewBag.TenKH = kh.TenDangNhap;
            if (kh.Level_ND != 1)
            {
                return RedirectToAction("AdminIndex");
            }
           else
            {
                List<TINTUC> dstt = db.TINTUC.OrderBy(x => x.ID_TinTuc).Where(k => k.MaND == kh.MaND).ToList();
                int pagesize = 6;
                int pagenumber = page ?? 1;
                return View(dstt.ToPagedList(pagenumber, pagesize));
            } 
        }
        //public ActionResult NguoiDungIndex(int? page, string keySearch)
        //{
        //    NGUOIDUNG kh = (NGUOIDUNG)Session["KhachHang"];
        //    ViewBag.TenKH = kh.TenDangNhap;
        //    List<TINTUC> dstt = null;
        //    if (keySearch != null)
        //    {
        //        dstt = db.TINTUC.Where(x => x.NoiDung.ToUpper().Contains(keySearch) || x.TienIch.ToUpper().Contains(keySearch) || x.DichVu.ToUpper().Contains(keySearch) || x.TieuDe.ToUpper().Contains(keySearch) || x.GiaTien.ToString().Contains(keySearch)).ToList();
        //        ViewBag.tieude = "kết quả tìm được";
        //    }
        //    dstt = db.TINTUC.OrderBy(x => x.MaLoaiTT).ToList();
        //    int pagesize = 6;
        //    int pagenumber = page ?? 1;
        //    return View(dstt.ToPagedList(pagenumber, pagesize));
        //}
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TINTUC tINTUC = db.TINTUC.Find(id);
            if (tINTUC == null)
            {
                return HttpNotFound();
            }
            return View(tINTUC);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TINTUC tINTUC = db.TINTUC.Find(id);
            if (tINTUC == null)
            {
                return HttpNotFound();
            }
            ViewBag.MaLoaiTT = new SelectList(db.THELOAITIN, "MaLoaiTT", "TenTL", tINTUC.MaLoaiTT);
            return View(tINTUC);
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult Update(TINTUC tINTUC)
        {
            if (ModelState.IsValid)
            {
                var x = Request.Files["upHinh"];
                string path = Server.MapPath("~/IndexLayout/images/imagePhongNha/" + x.FileName);
                x.SaveAs(path);
                tINTUC.Anh = x.FileName;
                db.Entry(tINTUC).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            db.Entry(tINTUC).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
            ViewBag.MaLoaiTT = new SelectList(db.THELOAITIN, "MaLoaiTT", "TenTL", tINTUC.MaLoaiTT);
            return View(tINTUC);
        }
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TINTUC tINTUC = db.TINTUC.Find(id);
            if (tINTUC == null)
            {
                return HttpNotFound();
            }
            return View(tINTUC);
        }

        // POST: QuanTri_ND/TINTUCNguoiDung/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            TINTUC tINTUC = db.TINTUC.Find(id);
            db.TINTUC.Remove(tINTUC);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public ActionResult Create()
        {
            NGUOIDUNG kh = (NGUOIDUNG)Session["KhachHang"];
            ViewBag.MaND = kh.MaND;
            ViewBag.MaHuyen = new SelectList(db.HUYENQUAN, "MaHuyen", "TenHuyen");
            ViewBag.MaTinh = new SelectList(db.TINHTP, "MaTinh", "TenTinh");
           // List<PHUONGXA> dsPhuong = db.PHUONGXA.Where(x => x.MaHuyen == SelectListItem(ViewBag.MaHuyen)).ToList();
            ViewBag.MaPhuong = new SelectList(db.PHUONGXA, "MaPhuong", "TenPhuong");
           // ViewBag.MaND = new SelectList(db.NGUOIDUNG, "MaND", "TenDangNhap");
            ViewBag.MaLoaiTT = new SelectList(db.THELOAITIN, "MaLoaiTT", "TenTL");
            return View();
        }

        // POST: QuanTri_ND/TINTUCs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(TINTUC tINTUC)
        {
            NGUOIDUNG kh = (NGUOIDUNG)Session["KhachHang"];
            ViewBag.MaND = kh.MaND;
            if (ModelState.IsValid)
            {
                var x = Request.Files["upHinh"];
                string path = Server.MapPath("~/IndexLayout/images/imagePhongNha/" + x.FileName);
                x.SaveAs(path);
                tINTUC.Anh = x.FileName;
                db.TINTUC.Add(tINTUC);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.MaTinh = new SelectList(db.TINHTP, "MaTinh", "TenTinh", tINTUC.MaTinh);
            ViewBag.MaHuyen = new SelectList(db.HUYENQUAN, "MaHuyen", "TenHuyen", tINTUC.MaHuyen);
            ViewBag.MaPhuong = new SelectList(db.PHUONGXA, "MaPhuong", "TenPhuong", tINTUC.MaPhuong);
            //ViewBag.MaND = new SelectList(db.NGUOIDUNG, "MaND", "TenDangNhap", tINTUC.MaND);
            ViewBag.MaLoaiTT = new SelectList(db.THELOAITIN, "MaLoaiTT", "TenTL", tINTUC.MaLoaiTT);
            return View(tINTUC);
        }
        public ActionResult AdminIndex(int? page, string keySearch, string MaHuyen)
        {
            List<TINTUC> dstt = null;
            if (keySearch != null)
            {
                dstt = db.TINTUC.Where(x => x.NoiDung.ToUpper().Contains(keySearch) || x.TienIch.ToUpper().Contains(keySearch) || x.DichVu.ToUpper().Contains(keySearch) || x.TieuDe.ToUpper().Contains(keySearch) || x.HUYENQUAN.TenHuyen.ToUpper().Contains(keySearch) || x.GiaTien.ToString().Contains(keySearch)).ToList();
                ViewBag.tieude = "kết quả tìm được";
            }
            else if(MaHuyen!=null)
            {
                dstt = db.TINTUC.Where(x => x.MaHuyen == MaHuyen).ToList();
                ViewBag.tieude = "kết quả lọc được";
            }
            else
            {
                dstt = db.TINTUC.OrderBy(x => x.MaLoaiTT).ToList();
                ViewBag.tieude = "Danh sách tất cả tin tức";

            }
            int pagesize = 6;
            int pagenumber = page ?? 1;
            ViewBag.keySearch = keySearch;
            ViewBag.MaHuyen = MaHuyen;
            return View(dstt.ToPagedList(pagenumber, pagesize));
        }

        public ActionResult NguoiDung()
        {
            NGUOIDUNG kh = (NGUOIDUNG)Session["KhachHang"];
            ViewBag.MatKhau= MaHoa.MD5(kh.PW_ND);
            return View(kh);
        }
        public ActionResult EditNguoiDung(int id)
        {
            NGUOIDUNG kh = db.NGUOIDUNG.Find(id);
        
            return View(kh);
        }
        public ActionResult UpdateNguoiDung(NGUOIDUNG model)
        {
            if (ModelState.IsValid)
            {
                db.Entry(model).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            db.Entry(model).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
            return View(model);
        }
    }
}