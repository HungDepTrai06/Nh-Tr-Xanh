﻿using System.Web.Mvc;

namespace WebBanHang.Areas.QuanTri_ND
{
    public class QuanTri_NDAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "QuanTri_ND";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "QuanTri_ND_default",
                "QuanTri_ND/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}