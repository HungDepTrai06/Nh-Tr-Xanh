﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanHang.Models;
using PagedList;
namespace WebBanHang.Controllers
{
    public class TinTucController : Controller
    {
        // GET: TinTuc
        public DBWebThue db = new DBWebThue();
        public ActionResult Index(int? page, int? MaLoaiTT, string MaHuyen, string keySearch, string IDGia, string IDDienTich)
        {
            //string keySearch = Request.Form["keySearch"];
            List<TINTUC> dstintuc=null;
            if (MaLoaiTT != null)
            {
                dstintuc = db.TINTUC.Where(x => x.MaLoaiTT == MaLoaiTT).ToList();
                ViewBag.tieude = "Kết quả tìm được";
            }
            else if (MaHuyen != null)
            {
                dstintuc = db.TINTUC.Where(x => x.MaHuyen == MaHuyen).ToList();
                ViewBag.tieude = "Kết quả tìm được";
            }
            else if (keySearch != null)
            {
                
                dstintuc = db.TINTUC.Where(x => x.NoiDung.ToUpper().Contains(keySearch) || x.TienIch.ToUpper().Contains(keySearch) || x.DichVu.ToUpper().Contains(keySearch) || x.TieuDe.ToUpper().Contains(keySearch) || x.HUYENQUAN.TenHuyen.ToUpper().Contains(keySearch) ||x.GiaTien.ToString().Contains(keySearch)).ToList();
                ViewBag.tieude = "kết quả tìm được";
            }
            else if (MaLoaiTT != null && MaHuyen != null)
            {
                dstintuc = db.TINTUC.Where(x => x.MaLoaiTT == MaLoaiTT && x.MaHuyen == MaHuyen).ToList();
                ViewBag.tieude = "Kết quả tìm được";
            }
            else if (IDGia == "1")
            {
                dstintuc = db.TINTUC.Where(x => x.GiaTien <= 2000000).ToList();
                ViewBag.tieude = "Kết quả tìm được";
            }
            else if (IDGia == "2")
            {
                dstintuc = db.TINTUC.Where(x => x.GiaTien >= 2000000 && x.GiaTien <= 3000000).ToList();
                ViewBag.tieude = "Kết quả tìm được";
            }
            else if (IDGia == "3")
            {
                dstintuc = db.TINTUC.Where(x => x.GiaTien >= 3000000 && x.GiaTien <= 4000000).ToList();
                ViewBag.tieude = "Kết quả tìm được";
            }
            else if (IDGia == "4")
            {
                dstintuc = db.TINTUC.Where(x => x.GiaTien >= 4000000 && x.GiaTien <= 5000000).ToList();
                ViewBag.tieude = "Kết quả tìm được";
            }
            else if (IDGia == "5")
            {
                dstintuc = db.TINTUC.Where(x => x.GiaTien >= 5000000).ToList();
                ViewBag.tieude = "Kết quả tìm được";
            }
            else if (IDDienTich == "1")
            {
                dstintuc = db.TINTUC.Where(x => x.DienTich <= 20).ToList();
                ViewBag.tieude = "Kết quả tìm được";
            }
            else if (IDDienTich == "2")
            {
                dstintuc = db.TINTUC.Where(x => x.DienTich >= 20 && x.GiaTien <= 30).ToList();
                ViewBag.tieude = "Kết quả tìm được";
            }
            else if (IDDienTich == "3")
            {
                dstintuc = db.TINTUC.Where(x => x.DienTich >= 30 && x.DienTich <= 40).ToList();
                ViewBag.tieude = "Kết quả tìm được";
            }
            else if (IDDienTich == "4")
            {
                dstintuc = db.TINTUC.Where(x => x.DienTich >= 40 && x.DienTich <= 50).ToList();
                ViewBag.tieude = "Kết quả tìm được";
            }
            else if (IDDienTich == "5")
            {
                dstintuc = db.TINTUC.Where(x => x.DienTich >= 50).ToList();
                ViewBag.tieude = "Kết quả tìm được";
            }
            else
            {
                dstintuc = db.TINTUC.ToList();
            }
            //dstintuc = db.TINTUC.ToList();
            ViewBag.tieude = "Tin tức nổi bật";
            int pageSize = 6;
            int pageNumber = page ?? 1;
            ViewBag.MaLoaiTT = MaLoaiTT;
            //ViewBag.MaHuyen = new SelectList(db.HUYENQUAN, "MaHuyen", "TenHuyen");
            ViewBag.MaHuyen = MaHuyen;
            ViewBag.keySearch = keySearch;
            ViewBag.IDGia = IDGia;
            ViewBag.IDDienTich = IDDienTich;
            return View(dstintuc.ToPagedList(pageNumber, pageSize));
        }
        public ActionResult Details(int id)
        {
            TINTUC tintuc = db.TINTUC.Find(id);

            return View(tintuc);
        }
    }
}