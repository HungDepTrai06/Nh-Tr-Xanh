﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebBanHang.Models;
namespace WebBanHang.Controllers
{
    public class CustommerController : Controller
    {
        DBWebThue db = new DBWebThue();
        // GET: Custommer
        public ActionResult Register(CustomerVielModel model)
        {
            if (ModelState.IsValid)
            {
                if (db.NGUOIDUNG.SingleOrDefault(x => x.Email == model.Email) != null)
                {
                    ModelState.AddModelError("", "Email đã tồn tại, hãy nhập lại");
                    return View();
                }
                if (db.NGUOIDUNG.SingleOrDefault(x => x.TenDangNhap == model.TenDangNhap) != null)
                {
                    ModelState.AddModelError("", "Tên đăng nhập này đã có, hãy nhập lại");
                    return View();
                }
                NGUOIDUNG kh = new NGUOIDUNG();
                kh.TenDangNhap = model.TenDangNhap;
                kh.Email = model.Email;
                kh.PW_ND = MaHoa.MD5(model.PW_ND);
                kh.DiaChi = model.DiaChi;
                kh.GioiTinh = model.GioiTinh;
                kh.HoTen = model.HoTen;
                kh.NgaySinh =Convert.ToDateTime(model.NgaySinh.ToShortDateString());
                kh.SDT = model.SDT;
                kh.NgayDK = Convert.ToDateTime(model.NgayDK.ToShortDateString());
                kh.Level_ND = model.Level_ND;
                db.NGUOIDUNG.Add(kh);
                db.SaveChanges();
                Session["KhachHang"] = kh; 
                return RedirectToAction("Index", "TinTuc");
            }
            return View();
        }
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(CustomerLoginView model)
        {
            if (ModelState.IsValid)
            {
                string mk = MaHoa.MD5(model.PW_ND);
                NGUOIDUNG kh = db.NGUOIDUNG.SingleOrDefault(x => x.TenDangNhap == model.TenDangNhap &&
                x.PW_ND ==mk );
                if (kh != null) 
                {
                    Session["KhachHang"] = kh;
                    return RedirectToAction("Index", "TinTuc");
                }
                else
                {
                    ModelState.AddModelError("", "Đăng nhập thất bại");
                }
            }
            return View();
        }
        public ActionResult LogOff()
        {
            Session.Clear();
            return RedirectToAction("Index", "TinTuc");
        }
    }
}