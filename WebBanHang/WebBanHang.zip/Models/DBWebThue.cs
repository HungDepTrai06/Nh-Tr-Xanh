namespace WebBanHang.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class DBWebThue : DbContext
    {
        public DBWebThue()
            : base("name=DBWebThue")
        {
        }

        public virtual DbSet<HUYENQUAN> HUYENQUAN { get; set; }
        public virtual DbSet<NGUOIDUNG> NGUOIDUNG { get; set; }
        public virtual DbSet<PHUONGXA> PHUONGXA { get; set; }
        public virtual DbSet<TINTUC> TINTUC { get; set; }
        public virtual DbSet<TINHTP> TINHTP { get; set; }
        public virtual DbSet<THELOAITIN> THELOAITIN { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<HUYENQUAN>()
                .Property(e => e.MaHuyen)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<HUYENQUAN>()
                .Property(e => e.MaTinh)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<NGUOIDUNG>()
                .Property(e => e.SDT)
                .IsFixedLength();

            modelBuilder.Entity<PHUONGXA>()
                .Property(e => e.MaPhuong)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<PHUONGXA>()
                .Property(e => e.MaHuyen)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<TINTUC>()
                .Property(e => e.MaHuyen)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<TINTUC>()
                .Property(e => e.MaTinh)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<TINTUC>()
                .Property(e => e.MaPhuong)
                .IsFixedLength()
                .IsUnicode(false);

            modelBuilder.Entity<TINHTP>()
                .Property(e => e.MaTinh)
                .IsFixedLength()
                .IsUnicode(false);
        }
    }
}
