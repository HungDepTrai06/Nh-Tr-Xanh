namespace WebBanHang.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("PHUONGXA")]
    public partial class PHUONGXA
    {
        [Key]
        [StringLength(6)]
        public string MaPhuong { get; set; }

        [StringLength(4)]
        public string MaHuyen { get; set; }

        [StringLength(50)]
        public string TenPhuong { get; set; }

        public virtual HUYENQUAN HUYENQUAN { get; set; }
    }
}
