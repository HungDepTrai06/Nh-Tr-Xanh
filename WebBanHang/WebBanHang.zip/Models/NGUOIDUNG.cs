﻿namespace WebBanHang.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("NGUOIDUNG")]
    public partial class NGUOIDUNG
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public NGUOIDUNG()
        {
            TINTUC = new HashSet<TINTUC>();
        }

        [Key]
        public int MaND { get; set; }

        [StringLength(30)]
        [Required(ErrorMessage = "Tên đăng nhập không thể rỗng")]
        [Display(Name = "Tên Đăng nhập")]
        public string TenDangNhap { get; set; }

        [StringLength(200)]
        [Required(ErrorMessage = "Password không thể rỗng")]

        [Display(Name = "Mật khẫu")]
        public string PW_ND { get; set; }

        [StringLength(80)]
        [Required(ErrorMessage = "Họ và tên không thể rỗng")]
        [Display(Name = "Họ và tên")]
        public string HoTen { get; set; }
        [Required(ErrorMessage = "Ngày sinh không thể rỗng")]
        [Display(Name = "Ngày sinh")]
        public DateTime? NgaySinh { get; set; }
        [Display(Name = "Giới tính")]
        public bool? GioiTinh { get; set; }

        [StringLength(60)]
        [Required(ErrorMessage = "Email không thể rỗng")]
        [EmailAddress(ErrorMessage = "Email không đúng, hãy nhập lại")]
        public string Email { get; set; }

        [StringLength(100)]
        [Required(ErrorMessage = "Địa chỉ không thể rỗng")]
        [Display(Name = "Địa chỉ")]
        public string DiaChi { get; set; }

        [StringLength(10)]
        [Required(ErrorMessage = "Số điện thoại không thể rỗng")]
        [Display(Name = "Số điện thoại")]
        public string SDT { get; set; }
        [Display(Name = "Ngày đăng ký")]
        public DateTime? NgayDK { get; set; }
        [Display(Name = "Level")]
        public int? Level_ND { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<TINTUC> TINTUC { get; set; }
    }
}
