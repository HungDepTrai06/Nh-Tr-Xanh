﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;

namespace WebBanHang.Models
{
    public class CustomerVielModel
    {
        [Required(ErrorMessage = "Tên đăng nhập không thể rỗng")]
        [Display(Name = "Tên Đăng nhập")]
        public string TenDangNhap { set; get; }

        [Required(ErrorMessage = "Họ và tên không thể rỗng")]
        [Display(Name = "Họ và tên")]
        public string HoTen { set; get; }

        [Required(ErrorMessage = "Ngày sinh không thể rỗng")]
        [Display(Name = "Ngày sinh")]
        public DateTime NgaySinh { set; get; }

        [Required(ErrorMessage = "Email không thể rỗng")]
        [EmailAddress(ErrorMessage = "Email không đúng, hãy nhập lại")]
        public string Email { set; get; }
        [Required(ErrorMessage = "Password không thể rỗng")]

        [Display(Name = "Mật khẫu")]
        public string PW_ND { set; get; }

        [Display(Name = "Nhập lại mật khẫu")]
        [Required(ErrorMessage = "Chưa nhập lại password")]
        [Compare("PW_ND")]
        public string PasswordConfirm { set; get; }


        [Display(Name = "Giới tính")]
        public Boolean GioiTinh { set; get; }

        [Required(ErrorMessage = "Địa chỉ không thể rỗng")]
        [Display(Name = "Địa chỉ")]
        public string DiaChi { set; get; }

        [Required(ErrorMessage = "Số điện thoại không thể rỗng")]
        [Display(Name = "Số điện thoại")]
        public string SDT { set; get; }

        [Display(Name = "Ngày đăng ký")]
        public DateTime NgayDK = DateTime.Now;
        [Display(Name = "Level")]
        public int Level_ND = 1;
    }
}