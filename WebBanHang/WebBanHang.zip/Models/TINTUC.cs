﻿namespace WebBanHang.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("TINTUC")]
    public partial class TINTUC
    {
        [Key]
        [Display(Name ="Mã tin tức")]
        [Required(ErrorMessage ="Mã tin tức không thể rỗng")]
        public int ID_TinTuc { get; set; }
        [Display(Name = "Tiệu đề")]
        [Required(ErrorMessage = "Tiêu đề không thể rỗng")]
        public string TieuDe { get; set; }

        [StringLength(50)]
        [Display(Name = "Ảnh")]
        public string Anh { get; set; }

        [Display(Name = "Nội dung")]
        [Required(ErrorMessage = "Nội dung không thể rỗng")]
        public string NoiDung { get; set; }

        [StringLength(4)]
        [Display(Name = "Mã huyện")]
        [Required(ErrorMessage = "Mã huyện không thể rỗng")]
        public string MaHuyen { get; set; }

        [StringLength(4)]
        [Display(Name = "Mã tỉnh")]
        [Required(ErrorMessage = "Mã tỉnh không thể rỗng")]
        public string MaTinh { get; set; }

        [StringLength(6)]
        [Display(Name = "Mã phường")]
        [Required(ErrorMessage = "Mã phường không thể rỗng")]
        public string MaPhuong { get; set; }

        [Display(Name = "Mã người dùng")]
       
        public int? MaND { get; set; }
        [Display(Name = "Diện tích")]
        [Required(ErrorMessage = "Diện tích không thể rỗng")]
        public double? DienTich { get; set; }
        [Display(Name = "Địa chỉ")]
        [Required(ErrorMessage = "Địa chỉ không thể rỗng")]
        public string DiaChi { get; set; }
        [Display(Name = "Giá tiền")]
        [Required(ErrorMessage = "Giá tiền không thể rỗng")]
        public double? GiaTien { get; set; }
        [Display(Name = "Số người tối đa")]
        [Required(ErrorMessage = "Số người tối đa không thể rỗng")]
        public int? SoNguoiToiDa { get; set; }
        [Display(Name = "Tiện ích")]
        
        public string TienIch { get; set; }
        [Display(Name = "Giá điện")]
        [Required(ErrorMessage = "Giá điện không thể rỗng")]
        public double? GiaDien { get; set; }
        [Display(Name = "Dịch vụ")]
  
        public string DichVu { get; set; }

        public int? MaLoaiTT { get; set; }

        public bool? TrangThai { get; set; }

        public virtual NGUOIDUNG NGUOIDUNG { get; set; }

        public virtual THELOAITIN THELOAITIN { get; set; }
        public virtual HUYENQUAN HUYENQUAN { get; set; }
        public virtual PHUONGXA PHUONGXA { get; set; }
    }
}
