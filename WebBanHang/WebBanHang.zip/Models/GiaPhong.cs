﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebBanHang.Models
{
     
    public class GiaPhong
    {
        public double giaMax { get; set; }
        public double giaMin { get; set; }
    }
    public class ListGiaPhong
    {
        List<GiaPhong> list = new List<GiaPhong>
        {
            new GiaPhong{giaMin=1000000, giaMax=1500000},
            new GiaPhong{giaMin=1500000, giaMax=2000000},
            new GiaPhong{giaMin=2000000, giaMax=300000},
            new GiaPhong{giaMin=3000000, giaMax=4000000},
            new GiaPhong{giaMin=4000000, giaMax=5000000},
            new GiaPhong{giaMin=5000000, giaMax=10000000}
        };
    }
    
    
}