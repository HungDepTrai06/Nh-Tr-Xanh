﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;

namespace WebBanHang.Models
{
    public class CustomerLoginView
    {
        [Required(ErrorMessage = "Tên đăng nhập không thể rỗng")]
        [Display(Name = "Tên Đăng nhập")]
        public string TenDangNhap { set; get; }

        [Required(ErrorMessage = "Password không thể rỗng")]

        [Display(Name = "Mật khẫu")]
        public string PW_ND { set; get; }
    }
}